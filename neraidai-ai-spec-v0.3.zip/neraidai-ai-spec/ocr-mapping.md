# 狙い台AI OCR入力対応表 v0.2

## 1. 目的

P’sCUBE等のスクリーンショットから、日別台データへ変換する際の項目対応を定義する。画面デザイン変更や読み取り誤りを前提に、必ず確認画面を挟む。

## 2. 読み取り対象

### 一覧画面
- 台番号
- BONUS/AT回数
- 前日・2日前・3日前の回数
- 最大放出枚数
- 総ゲーム数
- 現在ゲーム数または最終ゲーム数

### 台詳細画面
- 台番号
- 総ゲーム数
- AT/BIG回数
- CZ/REG回数
- 最大放出枚数
- グラフ画像
- 履歴

## 3. 保存先対応

| 画面上の項目 | DB項目 | 型 | 備考 |
|---|---|---:|---|
| 台番号 | machine_number_snapshot | text | 先頭ゼロを保持 |
| 累計G | total_games | integer | カンマ除去 |
| AT/BIG | at_big_count | integer | 機種ごとに表示名保持可 |
| CZ/REG | cz_reg_count | integer | 機種ごとに表示名保持可 |
| 最大放出 | max_payout | integer | 単位は枚 |
| 現在G | last_game_count | integer | 終了時点なら最終G |
| グラフ終点 | estimated_final_diff | integer nullable | 初版は手動推定可 |
| グラフ最高 | estimated_peak_diff | integer nullable | 同上 |
| グラフ最低 | estimated_bottom_diff | integer nullable | 同上 |
| グラフ形状 | graph_pattern | enum | 後述 |

## 4. グラフ形状

- `uptrend`：概ね右肩上がり
- `downtrend`：概ね右肩下がり
- `v_recovery`：大きく沈んで回復
- `inverted_v`：上昇後に大きく失速
- `flat`：横ばい
- `spike`：一撃型
- `multiple_waves`：複数の山
- `unknown`：判定不能
- `inactive`：未稼働

グラフ形状は設定判定ではなく、説明材料として使用する。

## 5. OCR信頼度

項目ごとに0.0〜1.0を保持する。

- 0.90以上：通常表示
- 0.70〜0.89：黄色表示、確認推奨
- 0.70未満：赤表示、保存前確認必須

台番号、総ゲーム数、最大放出は重要項目のため、低信頼なら必ず確認対象にする。

## 6. 画像重複・範囲重複

複数画像に同じ台が写る場合：
1. 台番号で候補を統合
2. 値が一致すれば高信頼化
3. 値が異なる場合はユーザーへ比較表示
4. 自動で新しい方を採用しない

## 7. 未稼働の扱い

以下が全て0の場合でも、未稼働か低表示データかを確認する。

- total_games = 0
- at_big_count = 0
- cz_reg_count = 0
- max_payout = 0

確定後に `activity_status = inactive` とする。未稼働は低設定扱いしない。

## 8. 日付判定

スクショ内の日付とユーザー指定日が一致しない場合は警告する。日付を自動変更しない。

## 9. 機種固有項目

初版では日別一覧に共通項目のみ保存する。橋示唆、真BIG、1G連などは実戦セッションへ手入力・画像添付する。
