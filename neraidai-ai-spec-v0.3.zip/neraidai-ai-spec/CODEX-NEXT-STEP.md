# Codexへ渡す次の指示

以下をCodexへそのまま渡してください。

---

このリポジトリにある `neraidai-ai-spec` フォルダ内の設計書をすべて読み、特に以下を優先してください。

- START-HERE.md
- project-rules.md
- requirements.md
- architecture.md
- database.md
- supabase-schema.sql
- wireframes.md
- acceptance-criteria.md
- codex-implementation-prompt.md

まずPhase 1のMVPだけを実装してください。予想AIやOCRの本実装を先行させないでください。

Phase 1の必須成果物：

1. Next.js + TypeScriptのスマホ優先PWA
2. Supabase接続
3. キクヤ堺本店を初期データとして登録できる
4. 複数機種を追加できる
5. 配置期間と台番号マッピングを管理できる
6. 日別データを一覧入力・編集・保存できる
7. スクショを複数アップロードして保存できる
8. 過去の日別データを閲覧できる
9. CSV/JSONエクスポートができる
10. Vercelへデプロイ可能な状態
11. セットアップ手順をREADMEへ記載
12. 基本的なテストと型チェックが通る

実装前に、設計書間の矛盾、必要な環境変数、実装順序を短く整理してください。大きな仕様変更が必要なら実装せず、変更案を提示してください。

---
