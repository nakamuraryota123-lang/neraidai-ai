# 狙い台AI 設計書 v0.3

キクヤ堺本店の営業データを蓄積し、ホール・配置・機種・実戦示唆を分けて検証する個人用分析PWAの設計書です。

## 最初に読むファイル

1. `START-HERE.md`
2. `beginner-setup-guide.md`
3. `project-rules.md`
4. `CODEX-NEXT-STEP.md`

## 設計書

- `vision.md`
- `requirements.md`
- `architecture.md`
- `database.md`
- `prediction-engine.md`
- `wireframes.md`
- `api.md`
- `ocr-mapping.md`
- `acceptance-criteria.md`
- `roadmap.md`
- `supabase-schema.sql`

## 実装開始

Codexへ渡す基本指示は `codex-implementation-prompt.md`、簡略版は `CODEX-NEXT-STEP.md` にあります。

## v0.3の主な追加

- Googleドライブを資料・画像・バックアップ保管に利用
- GitHub privateでコード管理
- Supabaseで共有データ保存
- Vercelで家・職場・スマホから利用
- 初心者向けの具体的手順
