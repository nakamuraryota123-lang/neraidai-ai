# 狙い台AI データベース設計 v0.1

## 1. 設計方針

台番号を主キーにしない。

履歴は以下の階層で保持する。

ホール → エリア/島 → 機種設置 → 配置期間 → 相対位置 → 日別結果

## 2. 主要エンティティ

### halls
- id
- name
- address_text
- timezone
- created_at
- updated_at

### machine_models
- id
- name
- manufacturer
- category
- introduced_at
- retired_at
- notes

### hall_areas
- id
- hall_id
- name
- floor
- description
- orientation

### machine_installations
- id
- hall_id
- machine_model_id
- hall_area_id
- group_name
- installed_from
- installed_to
- notes

### layout_periods
- id
- machine_installation_id
- valid_from
- valid_to
- machine_count
- layout_version
- source_image_id
- notes

### machine_positions
- id
- layout_period_id
- position_index
- physical_label
- machine_number
- side
- normalized_position
- is_left_edge
- is_right_edge
- is_left_second
- is_right_second
- is_center
- aisle_side
- wall_side
- notes

### daily_machine_results
- id
- business_date
- machine_position_id
- machine_number_snapshot
- total_games
- at_big_count
- cz_reg_count
- max_payout
- last_game_count
- estimated_final_diff
- estimated_peak_diff
- estimated_bottom_diff
- graph_pattern
- activity_status
- data_quality
- notes
- created_at
- updated_at

### screenshot_assets
- id
- hall_id
- machine_model_id
- business_date
- file_path
- image_type
- ocr_status
- uploaded_at

### ocr_extractions
- id
- screenshot_asset_id
- raw_text
- extracted_json
- confidence
- corrected_json
- status

### play_sessions
- id
- business_date
- machine_position_id
- started_at
- ended_at
- investment_yen
- payout_yen
- result_coins
- notes

### play_signals
- id
- play_session_id
- signal_type
- signal_value
- game_count
- image_id
- notes

### hall_events
- id
- hall_id
- business_date
- event_name
- event_type
- source_text
- image_id
- notes

### predictions
- id
- business_date
- hall_id
- machine_model_id
- layout_period_id
- generated_at
- model_version
- input_snapshot_json
- overall_confidence
- caveats

### prediction_candidates
- id
- prediction_id
- machine_position_id
- rank_type
- rank_order
- score
- confidence
- reasons_json
- risks_json

### evaluations
- id
- prediction_id
- evaluated_at
- evaluation_status
- summary
- lessons_json

### candidate_evaluations
- id
- evaluation_id
- prediction_candidate_id
- outcome_type
- payout_outcome
- behavior_outcome
- confidence
- notes

### hypotheses
- id
- hall_id
- machine_model_id nullable
- name
- description
- status
- evidence_for
- evidence_against
- confidence
- created_at
- updated_at

## 3. 位置の扱い

相対位置は0.0〜1.0で保持する。

例：10台構成
- 左端：0.0
- 左から2番目：0.111...
- 右端：1.0

台数変更後も、角・角2・中央・左右半分などの比較を継続できる。

## 4. 機種撤去後に残すデータ

- ホール全体の据え置き傾向
- 位置傾向
- 曜日傾向
- イベント傾向
- 当たり位置の移動距離
- 単品/並び/全台系の傾向

機種固有のCZ・示唆・AT挙動は、機種カルテとして履歴保存する。

## 5. データ品質

各日別データに品質フラグを付ける。

- verified：人が確認済み
- ocr_high：OCR高信頼
- ocr_low：OCR低信頼
- manual：手入力
- incomplete：欠損あり
- estimated：グラフから推定

予想時には、低品質データの重みを下げる。
