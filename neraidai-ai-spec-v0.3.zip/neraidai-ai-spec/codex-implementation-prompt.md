# Codexへ渡す最初の実装指示書

あなたは「狙い台AI」のPhase 1（データ収集MVP）を実装してください。

## 参照資料

リポジトリ直下の以下を必ず読んでから実装してください。

- `docs/vision.md`
- `docs/requirements.md`
- `docs/architecture.md`
- `docs/database.md`
- `docs/wireframes.md`
- `docs/api.md`
- `docs/ocr-mapping.md`
- `docs/prediction-engine.md`
- `docs/roadmap.md`

## 今回の実装範囲

予想AIはまだ実装しません。新台データをすぐ蓄積できる状態を最優先にします。

### 必須

1. Next.js App Router + TypeScript
2. Tailwind CSS
3. Supabase Auth、PostgreSQL、Storage
4. PWA対応
5. 初回セットアップ
6. ホール登録・編集
7. 機種登録・編集
8. エリア・設置・配置期間・相対位置の登録
9. 配置期間を上書きせず履歴化
10. スクリーンショット複数アップロード
11. OCRはモック実装から開始し、手入力で10台分を保存可能にする
12. OCR確認・修正UI
13. 日別結果の一括保存
14. 日別履歴一覧・詳細
15. CSV/JSONエクスポート
16. iPhoneのホーム画面から起動できる

### 初期データ

- ホール：キクヤ堺本店
- 機種：L真打吉宗
- 配置グループ：メイン島
- 台番号：0531〜0540
- 左から1〜10番目

初期データはseedで投入できるようにし、UIから変更可能にしてください。

## 重要な設計ルール

- 台番号を主キーにしない
- `layout_period` と `machine_position` を中心に履歴管理する
- 先頭ゼロを含む台番号は文字列として保存する
- 過去配置を削除・上書きしない
- 未稼働を低設定扱いしない
- 元画像を保存する
- OCR値は必ず人が確認してから `verified` にする
- RLSを有効化し、ユーザー本人以外は参照不可
- 削除操作には確認ダイアログを付ける

## UI要件

- 日本語UI
- iPhoneを主対象
- 画面下部の固定ナビゲーション
- 10台分を3分以内に入力できる
- 数値入力はテンキー
- OCR低信頼セルを色とアイコンで表示
- 読み取り前でも手入力へ進める
- 画像アップロード中、保存中、失敗時の状態を表示

## データベース

`supabase/migrations` にSQLマイグレーションを作成してください。

最低限のテーブル：

- profiles
- halls
- machine_models
- hall_areas
- machine_installations
- layout_periods
- machine_positions
- screenshot_assets
- ocr_extractions
- daily_machine_results

全テーブルに `user_id` または所有者をたどれる外部キーを持たせ、RLSポリシーを作成してください。

## OCRモック

Phase 1では外部OCR APIを必須にしません。

- アップロード後に「モック読み取り」ボタンを表示
- 初期配置の台番号を行として生成
- 数値欄は空欄または0
- ユーザーが一覧で修正して保存
- 後から実OCRへ置き換えやすいinterfaceを作る

推奨interface：

```ts
export interface OcrProvider {
  extractDailyResults(input: OcrInput): Promise<OcrDailyResult[]>;
}
```

## テスト

最低限、以下の自動テストを追加してください。

1. 台番号の先頭ゼロが保持される
2. 同じ配置期間・同じ位置・同じ営業日の重複保存を防ぐ
3. 配置変更時に旧配置が残る
4. 別ユーザーのデータを取得できない
5. 未稼働データが保存できる
6. 10台分の一括保存が成功する

## 完了条件

- `npm install` → `npm run dev` で起動
- `.env.example` がある
- Supabaseローカルまたはクラウドへの設定手順がREADMEにある
- seedコマンドで初期ホール・機種・配置が作られる
- iPhoneサイズで主要画面が崩れない
- lint、typecheck、testが通る
- 実装内容と未実装項目をREADMEへ記載する

## 作業の進め方

1. 既存ファイルと設計書を確認
2. 実装計画を短く提示
3. DBマイグレーションから着手
4. 画面を小さく分けて実装
5. 各段階でlint・typecheck・test
6. 最後に手動確認手順を提示

曖昧な部分は勝手に大規模変更せず、設計書の原則を優先してください。
