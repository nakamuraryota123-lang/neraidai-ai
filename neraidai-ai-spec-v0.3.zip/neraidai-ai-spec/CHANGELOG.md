# Changelog

## v0.3 — 2026-08-06

- 初心者向け開始手順を追加
- Googleドライブ、GitHub、Supabase、Vercelの役割分担を追加
- 家・職場・スマホで同じデータを使うクラウド運用を明文化
- Googleドライブの推奨フォルダ構成を追加
- 開発ルールを追加
- Codexへ渡す次の指示を追加
- シークレット管理とバックアップ方針を追加

## v0.2

- ワイヤーフレーム
- API仕様
- OCR項目対応
- Supabase SQL草案
- 受け入れ基準
- Codex実装指示

## v0.1

- Vision
- Requirements
- Architecture
- Database
- Prediction Engine
- Roadmap
