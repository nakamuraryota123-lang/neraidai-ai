-- 狙い台AI Supabase schema draft v0.2
create extension if not exists pgcrypto;

create type public.activity_status as enum ('active','inactive','partial','unknown');
create type public.data_quality as enum ('verified','ocr_high','ocr_low','manual','incomplete','estimated');
create type public.ocr_status as enum ('pending','processing','completed','failed','needs_review');
create type public.graph_pattern as enum ('uptrend','downtrend','v_recovery','inverted_v','flat','spike','multiple_waves','unknown','inactive');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.halls (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  address_text text,
  timezone text not null default 'Asia/Tokyo',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.machine_models (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  manufacturer text,
  category text,
  introduced_at date,
  retired_at date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.hall_areas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  hall_id uuid not null references public.halls(id) on delete cascade,
  name text not null,
  floor text,
  description text,
  orientation text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.machine_installations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  hall_id uuid not null references public.halls(id) on delete cascade,
  machine_model_id uuid not null references public.machine_models(id) on delete restrict,
  hall_area_id uuid references public.hall_areas(id) on delete set null,
  group_name text not null,
  installed_from date not null,
  installed_to date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (installed_to is null or installed_to >= installed_from)
);

create table public.layout_periods (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  machine_installation_id uuid not null references public.machine_installations(id) on delete cascade,
  valid_from date not null,
  valid_to date,
  machine_count integer not null check (machine_count > 0),
  layout_version integer not null default 1,
  orientation text not null default 'left-to-right',
  source_image_path text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (valid_to is null or valid_to >= valid_from)
);

create table public.machine_positions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  layout_period_id uuid not null references public.layout_periods(id) on delete cascade,
  position_index integer not null check (position_index > 0),
  physical_label text,
  machine_number text not null,
  side text,
  normalized_position numeric(6,5) not null check (normalized_position >= 0 and normalized_position <= 1),
  is_left_edge boolean not null default false,
  is_right_edge boolean not null default false,
  is_left_second boolean not null default false,
  is_right_second boolean not null default false,
  is_center boolean not null default false,
  aisle_side boolean,
  wall_side boolean,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(layout_period_id, position_index),
  unique(layout_period_id, machine_number)
);

create table public.screenshot_assets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  hall_id uuid not null references public.halls(id) on delete cascade,
  machine_model_id uuid references public.machine_models(id) on delete set null,
  business_date date not null,
  storage_path text not null,
  image_type text not null,
  content_hash text,
  ocr_status public.ocr_status not null default 'pending',
  uploaded_at timestamptz not null default now(),
  unique(user_id, storage_path)
);

create table public.ocr_extractions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  screenshot_asset_id uuid not null references public.screenshot_assets(id) on delete cascade,
  provider text not null default 'mock',
  provider_version text,
  raw_text text,
  extracted_json jsonb not null default '{}'::jsonb,
  confidence numeric(5,4),
  corrected_json jsonb,
  status public.ocr_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.daily_machine_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  business_date date not null,
  machine_position_id uuid not null references public.machine_positions(id) on delete restrict,
  machine_number_snapshot text not null,
  total_games integer check (total_games is null or total_games >= 0),
  at_big_count integer check (at_big_count is null or at_big_count >= 0),
  cz_reg_count integer check (cz_reg_count is null or cz_reg_count >= 0),
  max_payout integer check (max_payout is null or max_payout >= 0),
  last_game_count integer check (last_game_count is null or last_game_count >= 0),
  estimated_final_diff integer,
  estimated_peak_diff integer,
  estimated_bottom_diff integer,
  graph_pattern public.graph_pattern not null default 'unknown',
  activity_status public.activity_status not null default 'unknown',
  data_quality public.data_quality not null default 'manual',
  source_screenshot_ids uuid[] not null default '{}',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(business_date, machine_position_id)
);

create index daily_results_date_idx on public.daily_machine_results (business_date desc);
create index daily_results_position_idx on public.daily_machine_results (machine_position_id, business_date desc);
create index screenshots_date_idx on public.screenshot_assets (hall_id, business_date desc);

-- RLS
alter table public.profiles enable row level security;
alter table public.halls enable row level security;
alter table public.machine_models enable row level security;
alter table public.hall_areas enable row level security;
alter table public.machine_installations enable row level security;
alter table public.layout_periods enable row level security;
alter table public.machine_positions enable row level security;
alter table public.screenshot_assets enable row level security;
alter table public.ocr_extractions enable row level security;
alter table public.daily_machine_results enable row level security;

create policy "profiles own row" on public.profiles for all using (id = auth.uid()) with check (id = auth.uid());

-- All other tables use user_id ownership.
do $$
declare t text;
begin
  foreach t in array array['halls','machine_models','hall_areas','machine_installations','layout_periods','machine_positions','screenshot_assets','ocr_extractions','daily_machine_results']
  loop
    execute format('create policy %I on public.%I for all using (user_id = auth.uid()) with check (user_id = auth.uid())', t || '_own_rows', t);
  end loop;
end $$;

-- New auth user profile trigger
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
