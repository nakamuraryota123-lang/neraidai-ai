# 狙い台AI API仕様 v0.2

## 1. 方針

- Next.js Route HandlersまたはServer Actionsを利用する
- クライアントからOpenAI等のAI APIへ直接接続しない
- Supabase RLSを有効化し、全レコードをユーザー単位で隔離する
- APIレスポンスは原則JSON
- OCR・予想は非同期ジョブ化できる構造にする

## 2. 認証

Supabase Authを使用する。

初版は以下のいずれか。
- Magic Link
- メール＋パスワード

全APIでセッションを検証し、`user_id` をサーバー側で付与する。

## 3. エンドポイント

### 3.1 ホール

#### GET `/api/halls`
ユーザーのホール一覧を返す。

#### POST `/api/halls`
```json
{
  "name": "キクヤ堺本店",
  "timezone": "Asia/Tokyo"
}
```

#### PATCH `/api/halls/:hallId`
ホール名、メモを更新する。

### 3.2 機種

#### GET `/api/machine-models`
機種マスタ一覧。

#### POST `/api/machine-models`
```json
{
  "name": "L真打吉宗",
  "manufacturer": "大都技研",
  "category": "smart-slot"
}
```

### 3.3 設置・配置

#### POST `/api/installations`
```json
{
  "hallId": "uuid",
  "machineModelId": "uuid",
  "hallAreaId": "uuid",
  "groupName": "メイン島",
  "installedFrom": "2026-08-01"
}
```

#### POST `/api/layout-periods`
```json
{
  "machineInstallationId": "uuid",
  "validFrom": "2026-08-01",
  "orientation": "left-to-right",
  "positions": [
    {"positionIndex": 1, "machineNumber": "0531"},
    {"positionIndex": 2, "machineNumber": "0532"}
  ]
}
```

#### POST `/api/layout-periods/:id/close`
```json
{"validTo": "2026-08-20"}
```

### 3.4 画像アップロード

#### POST `/api/screenshots/presign`
Storageへの署名付きアップロード情報を返す。

#### POST `/api/screenshots/complete`
```json
{
  "hallId": "uuid",
  "machineModelId": "uuid",
  "businessDate": "2026-08-04",
  "imageType": "daily-result",
  "storagePath": "..."
}
```

### 3.5 OCR

#### POST `/api/ocr/jobs`
```json
{
  "businessDate": "2026-08-04",
  "hallId": "uuid",
  "machineModelId": "uuid",
  "layoutPeriodId": "uuid",
  "screenshotAssetIds": ["uuid1", "uuid2"]
}
```

レスポンス：
```json
{"jobId": "uuid", "status": "queued"}
```

#### GET `/api/ocr/jobs/:jobId`
```json
{
  "status": "completed",
  "rows": [
    {
      "positionIndex": 1,
      "machineNumber": "0531",
      "totalGames": 850,
      "atBigCount": 9,
      "czRegCount": 2,
      "maxPayout": 320,
      "confidence": {
        "totalGames": 0.97,
        "maxPayout": 0.61
      }
    }
  ]
}
```

### 3.6 日別結果

#### PUT `/api/daily-results/bulk`
確認・修正済みの10台分を一括保存する。

```json
{
  "businessDate": "2026-08-04",
  "layoutPeriodId": "uuid",
  "sourceScreenshotIds": ["uuid"],
  "rows": [
    {
      "machinePositionId": "uuid",
      "machineNumberSnapshot": "0531",
      "totalGames": 850,
      "atBigCount": 9,
      "czRegCount": 2,
      "maxPayout": 320,
      "activityStatus": "active",
      "dataQuality": "verified"
    }
  ]
}
```

#### GET `/api/daily-results`
クエリ：`hallId`, `machineModelId`, `from`, `to`, `layoutPeriodId`

### 3.7 予想

#### POST `/api/predictions`
```json
{
  "businessDate": "2026-08-05",
  "hallId": "uuid",
  "machineModelId": "uuid",
  "layoutPeriodId": "uuid"
}
```

サーバー側処理：
1. 前日・直近3日・7日を取得
2. イベント、仮説、過去予想、答え合わせを取得
3. 構造化入力スナップショットを生成
4. 予想LLMを呼び出す
5. JSON Schemaで検証
6. predictionsとprediction_candidatesへ保存

レスポンス：
```json
{
  "predictionId": "uuid",
  "overallConfidence": "medium",
  "dataSummary": {"businessDays": 3, "machineDays": 30},
  "candidates": [
    {
      "rankType": "main",
      "rankOrder": 1,
      "machinePositionId": "uuid",
      "machineNumber": "0536",
      "relativeLabel": "左から6番目",
      "reasons": ["前日低稼働", "中央寄り仮説と一致"],
      "risks": ["検証数が少ない"]
    }
  ],
  "caveats": ["未稼働台が3台あります"]
}
```

### 3.8 答え合わせ

#### POST `/api/predictions/:predictionId/evaluate`
```json
{
  "evaluationStatus": "completed",
  "candidateOutcomes": [
    {
      "predictionCandidateId": "uuid",
      "outcomeType": "miss",
      "payoutOutcome": "weak",
      "behaviorOutcome": "unknown",
      "notes": "低稼働"
    }
  ],
  "actualNotablePositionIds": ["uuid"],
  "failedHypothesisIds": ["uuid"],
  "summary": "凹み上げを重視しすぎた"
}
```

### 3.9 カルテ

#### GET `/api/calendars/hall/:hallId`
ホール共通集計。

#### GET `/api/calendars/machine/:installationId`
機種・設置期間別集計。

## 4. エラー形式

```json
{
  "error": {
    "code": "OCR_LOW_CONFIDENCE",
    "message": "読み取り結果に確認が必要です",
    "details": {}
  }
}
```

主要コード：
- `UNAUTHORIZED`
- `VALIDATION_ERROR`
- `LAYOUT_MISMATCH`
- `DUPLICATE_DAILY_RESULT`
- `OCR_FAILED`
- `OCR_LOW_CONFIDENCE`
- `INSUFFICIENT_DATA`
- `PREDICTION_SCHEMA_ERROR`

## 5. 冪等性

- 一括結果保存は `business_date + machine_position_id` を一意にする
- 画像完了APIはstorage pathで重複防止
- 予想生成は同一対象日について再生成可能だが、過去版を削除しない
